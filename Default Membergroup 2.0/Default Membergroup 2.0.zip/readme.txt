[size=20pt][color=green][font=times new roman]Default Membergroup[/font][/color][/size] [size=14pt][color=orange][font=times new roman]2.0[/font][/color][/size] 
----------------------------------------------------------------------------------------------------------------------------------------------------
[size=0.7em][b]Author:[/b] Runic
  [b]Versions: [/b]2.0.X
  [b]Available since: [/b]April 26 '09 
  [b]Latest version:[/b] 2.0 (17 December 2012)[/size]

[size=13pt][color=maroon][u][b]Introduction[/b][/u][/color][/size]
This mod assigns all new members to a specific membergroup upon registration. 
The group is set by ID in the 'Registration' section of your administration panel.
