[center]
[hr]
[color=purple][size=16pt][b]Random Pagan Verse[/b][/size][/color]
[b]Created by Runic[/b]
[hr]
[url=http://www.bryandeakin.com][b]Support[/b][/url] | [url=https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=SS58QTJY3HXU2&lc=GB&item_name=Mods%20and%20Themes&item_number=1&currency_code=GBP&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted][b]Donate[/b][/url]
[hr]
[/center][b][size=12pt][u]Compatibility[/u][/size][/b]
For SMF 2.0.3

[color=purple][b][size=12pt][u]Introduction[/u][/size][/b][/color]

This is a combination of four pagan texts, you can choose from:

[*]Random Havamal Verse
[*]Random Wiccan Rede Verse
[*]Random Witch's Law Verse
[*]Random Thelema Quotation

Or if you wish to show them all this is also possible.

The mod combines all the files into 1 language file and gives users the option of displaying what verse they would like to display.

This mod is designed for a Pagan Community.

[b]A very big thank you goes to IchBin for updating this mod so that it makes no file edits and so that it works with all portals!![/b]