Admin Notes is a simple mod designed to be an easy way for admins to leave notes for other admins or simply a place for admins to chat. It is located in the administration centre next to the live news (support information is moved below live news).

It is similar to "Moderator Notes" found in the moderator centre and uses tables that have already been created meaning the database isn't changed at all when installing this mod.

For any questions, suggestions or bug reports do not hesitate to post in the [url=http://www.simplemachines.org/community/index.php?topic=308803.0]support thread[/url].

Cheers,
Runic