[center]
[hr]
[color=purple][size=16pt][b]View Post Count[/b][/size][/color]
[b]Created by Runic[/b]
[hr]
[url=http://www.bryandeakin.com][b]Support[/b][/url] | [url=https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=SS58QTJY3HXU2&lc=GB&item_name=Mods%20and%20Themes&item_number=1&currency_code=GBP&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted][b]Donate[/b][/url]
[hr]

[/center][b][size=12pt][u]Compatibility[/u][/size][/b]
1.1.x

This mod allows the admin to set what group can or cannot see the postcount of a user.

v1.0
-Initial Release
V1.1
-Added English_british and UTF8 Support