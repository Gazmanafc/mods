[center]
[hr]
[color=purple][size=16pt][b]Daily Target[/b][/size][/color]
[b]Created by Runic[/b]
[hr]
[url=http://www.bryandeakin.com][b]Support[/b][/url] | [url=https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=SS58QTJY3HXU2&lc=GB&item_name=Mods%20and%20Themes&item_number=1&currency_code=GBP&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted][b]Donate[/b][/url]
[hr]
[/center][b][size=12pt][u]Compatibility[/u][/size][/b]
For SMF 2.0.x

[color=purple][b][size=12pt][u]Introduction[/u][/size][/b][/color]

This mod allows you to set a daily target of posts in your admin panel, it uses the layers system of 2.0 so should not require any theme edits.

v1.3
! Added English British 
! Added English British and English UTF8
v1.2
! Moves code to its on Source Directory
V1.1
! Moves DB stuff to subs.php
v1.0
+ Initial Release