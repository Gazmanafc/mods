[center]
[hr]
[color=purple][size=16pt][b]New Some / New None Image remover[/b][/size][/color]
[b]Created by Runic[/b]
[hr]
[url=http://www.bryandeakin.com][b]Support[/b][/url] | [url=https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=SS58QTJY3HXU2&lc=GB&item_name=Mods%20and%20Themes&item_number=1&currency_code=GBP&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted][b]Donate[/b][/url]
[hr]
[/center][b][size=12pt][u]Compatibility[/u][/size][/b]

2.0.3

This Mod gives option to remove the new_none and new_some images from the boardindex.template.php, it can be turned off and on from Modification Settings in the admin panel.

This is a re-write of my original mod of the same name but updated for 2.0.3 using more updated standards.
