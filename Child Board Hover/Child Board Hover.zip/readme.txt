[b]Child Board Hover[/b]

[b]Mod Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=23577]Runic[/url]
[b]SMF Version:[/b] 2.0.X
[b]Mod Version:[/b] 1.0

[b]Description:[/b]
Add more than just the Posts and Reply details to your Child Board Hover, this mod does that shows you more info including Child Board Description.
This mod also adds to the Message index so it works for grand children boards.
And if that was not enough, you can also choose where the mod works be it in just the MessageIndex or Just the BoardIndex or if your cRAZY then you can choose both!
Bring more control to your forum.

[b]PLEASE NOTE YOU NEED TO HAVE A DESCRIPTION IN YOUR CHILD BOARD FOR FULL EFFECTS OF THIS MOD[/b]

This mod does not include a redirect nor will it ever so to activate this mod simply go to Modification Settings and you will be able to activate it there.

[b]Bug Testers:[/b]
A big Thank You to the following people for bug testing the mod before release:

Colin

[b]Why Not Visit:[/b]
http://www.bryandeakin.com