<?php
// Version: 1.0: PMAutoResponder.english.php

// Important! Before editing these language files please read the text at the top of index.english.php.

$txt['ar_pm_enabled'] = 'Auto respond to PMs';
$txt['ar_pm_subject'] = 'Auto respond subject';
$txt['ar_pm_subject_desc'] = 'Subject of PM to send to users who PM you';
$txt['ar_pm_body'] = 'Auto respond message';
$txt['ar_pm_body_desc'] = 'The message to send';
$txt['ar_pm_outbox'] = 'Save message in outbox';
$txt['ar_pm_profile_area'] = 'PM Auto Response';

?>