[hr]
[center][color=purple][size=16pt][b]Signature Area BBCode Buttons v2.0.1[/b][/size][/color]
by Bryan Runic Deakin. Mod Originally by KarlBenson.
[/center]
[hr]
[center][url=http://custom.simplemachines.org/mods/index.php?mod=450]Link to Mod[/url] | [url=http://www.simplemachines.org/community/index.php?topic=111279.0]Comment On This Mod[/url] | [url=http://www.bryandeakin.com/]VIP Support[/u][/center]

[color=blue][b][size=12pt]Introduction[/size][/b][/color]
Adds a row of buttons of some of the most commonly used bbcode above the edit/add signature box in users profile area.

[b]For SMF 1.1.x and 2.0.X versions[/b]


[color=blue][b][size=12pt]Features[/size][/b][/color]
o Adds the default BBCode buttons on editing signature 
o  no text strings needed

[color=blue][b][size=12pt]Installation[/size][/b][/color]
Simply install the package to install on the SMF Default theme AND any other theme which does NOT have a custom Profile.template.php

[color=blue][b][size=12pt]Support[/b][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)

Support will also be given on Bryandeakin.com

[color=blue][b][size=12pt]Changelog[/size][/b][/color]

[b]2.0.3 14 January 2012[/b]
o - Updated mod for 1.1.12 and RC4
o - Updated Readme 

[b]2.0.2 25 November 2010[/b]
o - Updated mod for 1.1.12 and RC4
o - Updated Readme

[b]2.0.1 March 13 2010[/b]

o -  fixed an annoying bug:  if you go to forum profile to look at you signature or to modify it
you will not find your signature there.

[b]2.0 March 12 2010[/b]

o -  the mod now loads all the bbc buttons and smilies you have, even the ones that are added by other mods ;)   (only 2.0 RC2 and 2.0 RC3)


[b]1.7 - November 11 2009[/b]
o - Deleted the option to turn on/off theres no point of having that option :P
o - Deleted the text strings, no loger required
o - Added support for 2.0RC2
o - Added more bbc buttons
[b]1.6 - August 13 2009[/b]
o Take over by 130860. :)
o Fixed the Undefined offset: error in 2.0
o Added an option to turn on/off the mod
o Added support for 2.0 RC1.2
[b]1.5 - 30th November 2007[/b]
o Re-packaged mod
o Improved the readme.