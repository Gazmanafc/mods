This modification will create a new layout/look for
latest posts in infocenter and also ads a recent post 
link. in title

===============================
Author : Bryan Runic Deakin
http://www.bryandeakin.com/
===============================